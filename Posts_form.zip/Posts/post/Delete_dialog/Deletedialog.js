import React from "react";
import { useState } from "react";

import {
  Button,
  TextField,
  Dialog,
  DialogActions,
  DialogContent,
  DialogContentText,
  DialogTitle,
} from "@material-ui/core/";
import { deletePost } from "../../../../api";
import { loginUser } from "../../../../api";

const Deletedialog = ({ post, email }) => {
  const [open, setOpen] = useState(false);
  const [password, setPassword] = useState('');

  const handleSubmit = async (id) => {
    try {
      const { data } = await loginUser({ email, password });
      console.log(data)
      deletePost(id);
    } catch (error) {
      console.log(error);
    }
  }


  // const deleteHandler = (id) => {

    
  //     deletePost(id);
    

  // };

  const handleClickOpen = () => {
    setOpen(true);
  };

  const handleClose = () => {
    setOpen(false);
  };

  return (
    <div>


      <Button variant="outlined" onClick={handleClickOpen}>
        Delete post
      </Button>
      <Dialog open={open} onClose={handleClose}>
        <DialogTitle>Deleting Post</DialogTitle>
        <DialogContent>
          <DialogContentText>
            Please enter your password here.
          </DialogContentText>
          <TextField
            autoFocus
            margin="dense"
            id="name"
            label="Password"
            type="password"
            fullWidth
            variant="standard"
            onChange={(e) => {
              setPassword(e.target.value);
            }}
          />
        </DialogContent>
        <DialogActions>
          <Button onClick={() => 
            
            handleSubmit(post._id)} >Confirm Delete</Button>
          <Button onClick={handleClose}>Cancel</Button>
        </DialogActions>
      </Dialog>
    </div>
  );
};

export default Deletedialog;
