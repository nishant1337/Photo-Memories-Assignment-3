import React from "react";
import Post from "./post/Post";
import useStyles from './styles';
import { Grid, CircularProgress } from '@material-ui/core';


const Posts = ({posts, email , user}) => {
  const classes = useStyles();

  return (
    !posts.length ? <CircularProgress /> : (
      <Grid className={classes.container} container alignItems="stretch" spacing={3}>
        {posts.map((post) => (
          <Grid key={post._id} item xs={12} sm={6} md={6}>
            <Post post={post} user={user} email={email} />
          </Grid>
        ))}
      </Grid>
    )
  );
};

export default Posts;